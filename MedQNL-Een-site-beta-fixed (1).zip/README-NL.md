# MedQNL – één website met gesloten bèta-toegang

Dit pakket bevat bewust **één website** en één publiek startbestand: `index.html`.

Bij openen verschijnt eerst alleen de gesloten bèta-intro. Na het invoeren van het wachtwoord `Chanel` wordt in hetzelfde document de volledige MedQNL-omgeving zichtbaar. Er zijn dus geen twee aparte websites of twee versies om tussen te kiezen.

Deze wachtwoordbeveiliging is bedoeld voor een gesloten bèta/prototype. Voor een openbare productieomgeving is server-side toegangsbeveiliging nodig.
